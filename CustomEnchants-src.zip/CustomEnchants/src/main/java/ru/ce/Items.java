package ru.ce;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.ArrayList;
import java.util.List;

/** Хранение чаров в PersistentDataContainer предмета. */
public final class Items {
    private Items() {}

    private static NamespacedKey key(CE c) {
        return new NamespacedKey(Main.get(), c.id);
    }

    public static boolean has(ItemStack it, CE c) {
        if (it == null || it.getType().isAir() || !it.hasItemMeta()) return false;
        return it.getItemMeta().getPersistentDataContainer().has(key(c), PersistentDataType.BYTE);
    }

    public static void add(ItemStack it, CE c) {
        ItemMeta m = it.getItemMeta();
        m.getPersistentDataContainer().set(key(c), PersistentDataType.BYTE, (byte) 1);
        List<Component> lore = m.lore() == null ? new ArrayList<>() : new ArrayList<>(m.lore());
        lore.add(c.line());
        m.lore(lore);
        it.setItemMeta(m);
    }

    public static List<CE> enchants(ItemStack it) {
        List<CE> out = new ArrayList<>();
        for (CE c : CE.values()) {
            if (has(it, c)) out.add(c);
        }
        return out;
    }

    public static ItemStack book(CE c) {
        ItemStack it = new ItemStack(Material.ENCHANTED_BOOK);
        ItemMeta m = it.getItemMeta();
        m.displayName(Component.text("Книга: " + c.title, c.color)
                .decoration(TextDecoration.ITALIC, false));
        m.lore(List.of(
                c.line(),
                Component.text(c.desc, NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false),
                Component.text("Подходит для: " + targetName(c.target), NamedTextColor.DARK_GRAY)
                        .decoration(TextDecoration.ITALIC, false),
                Component.text("Наложи на предмет в наковальне", NamedTextColor.DARK_GRAY)
                        .decoration(TextDecoration.ITALIC, false)));
        m.getPersistentDataContainer().set(key(c), PersistentDataType.BYTE, (byte) 1);
        it.setItemMeta(m);
        return it;
    }

    private static String targetName(Target t) {
        return switch (t) {
            case DIGGER -> "кирка, лопата";
            case PICKAXE -> "кирка";
            case AXE -> "топор";
            case TOOL -> "кирка, лопата, топор";
            case SWORD -> "меч";
            case CHEST -> "нагрудник";
            case BOOTS -> "ботинки";
            case HELMET -> "шлем";
        };
    }
}
