package ru.ce;

import org.bukkit.Material;

/** На какие предметы можно наложить чар. */
public enum Target {
    DIGGER, PICKAXE, AXE, TOOL, SWORD, CHEST, BOOTS, HELMET;

    public boolean matches(Material m) {
        String n = m.name();
        return switch (this) {
            case DIGGER -> n.endsWith("_PICKAXE") || n.endsWith("_SHOVEL");
            case PICKAXE -> n.endsWith("_PICKAXE");
            case AXE -> n.endsWith("_AXE");
            case TOOL -> n.endsWith("_PICKAXE") || n.endsWith("_SHOVEL") || n.endsWith("_AXE");
            case SWORD -> n.endsWith("_SWORD");
            case CHEST -> n.endsWith("_CHESTPLATE");
            case BOOTS -> n.endsWith("_BOOTS");
            case HELMET -> n.endsWith("_HELMET");
        };
    }
}
