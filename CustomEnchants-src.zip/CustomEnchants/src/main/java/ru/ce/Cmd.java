package ru.ce;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;

/** Команда /ce и меню со всеми книгами (для админов / гейммастеров). */
public final class Cmd implements TabExecutor, Listener {

    private static final class Holder implements InventoryHolder {
        private Inventory inv;

        @Override
        public Inventory getInventory() {
            return inv;
        }
    }

    private void open(Player p) {
        Holder h = new Holder();
        Inventory inv = Bukkit.createInventory(h, 27,
                Component.text("Кастомные чары", NamedTextColor.DARK_PURPLE));
        h.inv = inv;
        int slot = 0;
        for (CE c : CE.values()) {
            inv.setItem(slot++, Items.book(c));
        }
        p.openInventory(inv);
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getView().getTopInventory().getHolder() instanceof Holder)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p) || !p.hasPermission("ce.admin")) return;
        if (e.getClickedInventory() == null
                || !(e.getClickedInventory().getHolder() instanceof Holder)) return;
        ItemStack it = e.getCurrentItem();
        if (it == null || it.getType() != Material.ENCHANTED_BOOK) return;
        p.getInventory().addItem(it.clone());
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof Holder) e.setCancelled(true);
    }

    @Override
    public boolean onCommand(CommandSender s, Command cmd, String label, String[] args) {
        if (!s.hasPermission("ce.admin")) {
            s.sendMessage(Component.text("Нет прав.", NamedTextColor.RED));
            return true;
        }
        if (args.length == 0) {
            if (s instanceof Player p) open(p);
            else s.sendMessage("Используй: /ce give <id> <игрок>");
            return true;
        }
        if (args[0].equalsIgnoreCase("reload")) {
            Main.get().reload();
            s.sendMessage(Component.text("Конфиг перезагружен.", NamedTextColor.GREEN));
            return true;
        }
        if (args[0].equalsIgnoreCase("give") && args.length >= 2) {
            CE c = CE.byId(args[1]);
            if (c == null) {
                s.sendMessage(Component.text("Нет такого чара: " + args[1], NamedTextColor.RED));
                return true;
            }
            Player target = args.length >= 3 ? Bukkit.getPlayerExact(args[2])
                    : (s instanceof Player p ? p : null);
            if (target == null) {
                s.sendMessage(Component.text("Игрок не найден.", NamedTextColor.RED));
                return true;
            }
            target.getInventory().addItem(Items.book(c));
            s.sendMessage(Component.text("Выдана книга: " + c.title, NamedTextColor.GREEN));
            return true;
        }
        s.sendMessage(Component.text("/ce | /ce give <id> [игрок] | /ce reload", NamedTextColor.GRAY));
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command cmd, String label, String[] args) {
        List<String> out = new ArrayList<>();
        if (args.length == 1) {
            out.add("give");
            out.add("reload");
        } else if (args.length == 2 && args[0].equalsIgnoreCase("give")) {
            for (CE c : CE.values()) out.add(c.id);
        } else if (args.length == 3 && args[0].equalsIgnoreCase("give")) {
            for (Player p : Bukkit.getOnlinePlayers()) out.add(p.getName());
        }
        String last = args.length == 0 ? "" : args[args.length - 1].toLowerCase();
        out.removeIf(x -> !x.toLowerCase().startsWith(last));
        return out;
    }
}
