package ru.ce;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.Tag;
import org.bukkit.attribute.Attribute;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.entity.Item;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockDropItemEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.inventory.PrepareAnvilEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.world.LootGenerateEvent;
import org.bukkit.inventory.AnvilInventory;
import org.bukkit.inventory.FurnaceRecipe;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.Recipe;
import org.bukkit.inventory.RecipeChoice;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.RayTraceResult;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;
import java.util.function.Predicate;

public final class Events implements Listener {

    /** Игроки, у которых прямо сейчас идёт массовая ломка (защита от рекурсии). */
    private final Set<UUID> busy = new HashSet<>();
    /** Счётчик ударов для чара "Щит". */
    private final Map<UUID, Integer> aegis = new HashMap<>();
    private Map<Material, ItemStack> smeltMap;

    // ------------------------------------------------------------------
    // Бур 3x3, Дровосек, Жилокоп
    // ------------------------------------------------------------------
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        Player p = e.getPlayer();
        if (busy.contains(p.getUniqueId())) return;
        if (p.getGameMode() == GameMode.CREATIVE || p.getGameMode() == GameMode.SPECTATOR) return;

        ItemStack tool = p.getInventory().getItemInMainHand();
        if (tool.getType().isAir() || !tool.hasItemMeta()) return;

        Block b = e.getBlock();
        Set<Block> extra = new LinkedHashSet<>();

        if (Items.has(tool, CE.DRILL)) {
            drill(p, b, tool, extra);
        }
        if (Items.has(tool, CE.LUMBERJACK) && Tag.LOGS.isTagged(b.getType())) {
            collect(b, extra, 128, Tag.LOGS::isTagged);
        }
        if (Items.has(tool, CE.VEINMINER) && p.isSneaking() && isOre(b.getType())) {
            Material type = b.getType();
            collect(b, extra, 64, m -> m == type);
        }
        if (extra.isEmpty()) return;

        busy.add(p.getUniqueId());
        try {
            for (Block x : extra) {
                ItemStack hand = p.getInventory().getItemInMainHand();
                if (hand.getType().isAir()) break; // инструмент сломался
                p.breakBlock(x);
            }
        } finally {
            busy.remove(p.getUniqueId());
        }
    }

    private void drill(Player p, Block b, ItemStack tool, Set<Block> out) {
        RayTraceResult r = p.rayTraceBlocks(7.0);
        if (r == null || r.getHitBlockFace() == null) return;
        BlockFace f = r.getHitBlockFace();
        for (int i = -1; i <= 1; i++) {
            for (int j = -1; j <= 1; j++) {
                if (i == 0 && j == 0) continue;
                Block t;
                if (f.getModX() != 0) t = b.getRelative(0, i, j);
                else if (f.getModY() != 0) t = b.getRelative(i, 0, j);
                else t = b.getRelative(i, j, 0);
                if (canMine(t, tool)) out.add(t);
            }
        }
    }

    private boolean canMine(Block t, ItemStack tool) {
        Material m = t.getType();
        return !m.isAir() && !t.isLiquid() && m.getHardness() >= 0 && t.isPreferredTool(tool);
    }

    private void collect(Block start, Set<Block> out, int max, Predicate<Material> ok) {
        Set<Block> seen = new HashSet<>();
        Deque<Block> queue = new ArrayDeque<>();
        seen.add(start);
        queue.add(start);
        while (!queue.isEmpty() && out.size() < max) {
            Block c = queue.poll();
            for (int dx = -1; dx <= 1; dx++) {
                for (int dy = -1; dy <= 1; dy++) {
                    for (int dz = -1; dz <= 1; dz++) {
                        if (dx == 0 && dy == 0 && dz == 0) continue;
                        Block n = c.getRelative(dx, dy, dz);
                        if (seen.add(n) && ok.test(n.getType())) {
                            out.add(n);
                            queue.add(n);
                        }
                    }
                }
            }
        }
    }

    private boolean isOre(Material m) {
        return m.name().endsWith("_ORE") || m == Material.ANCIENT_DEBRIS;
    }

    // ------------------------------------------------------------------
    // Плавильщик + Магнит
    // ------------------------------------------------------------------
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDrop(BlockDropItemEvent e) {
        Player p = e.getPlayer();
        ItemStack tool = p.getInventory().getItemInMainHand();
        if (tool.getType().isAir() || !tool.hasItemMeta()) return;

        if (Items.has(tool, CE.SMELTER)) {
            for (Item it : e.getItems()) {
                ItemStack s = it.getItemStack();
                ItemStack res = smelt().get(s.getType());
                if (res != null) {
                    ItemStack n = res.clone();
                    n.setAmount(Math.min(64, res.getAmount() * s.getAmount()));
                    it.setItemStack(n);
                }
            }
        }
        if (Items.has(tool, CE.MAGNET)) {
            Iterator<Item> iter = e.getItems().iterator();
            while (iter.hasNext()) {
                Item it = iter.next();
                Map<Integer, ItemStack> left = p.getInventory().addItem(it.getItemStack());
                if (left.isEmpty()) iter.remove();
                else it.setItemStack(left.values().iterator().next());
            }
        }
    }

    private Map<Material, ItemStack> smelt() {
        if (smeltMap == null) {
            smeltMap = new EnumMap<>(Material.class);
            Iterator<Recipe> it = Bukkit.recipeIterator();
            while (it.hasNext()) {
                if (it.next() instanceof FurnaceRecipe fr
                        && fr.getInputChoice() instanceof RecipeChoice.MaterialChoice mc) {
                    for (Material m : mc.getChoices()) {
                        smeltMap.putIfAbsent(m, fr.getResult());
                    }
                }
            }
        }
        return smeltMap;
    }

    // ------------------------------------------------------------------
    // Щит: 3 удара проходят, 4-й блокируется
    // ------------------------------------------------------------------
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onAegis(EntityDamageByEntityEvent e) {
        if (!(e.getEntity() instanceof Player p)) return;
        if (!Items.has(p.getInventory().getChestplate(), CE.AEGIS)) return;

        int hits = aegis.merge(p.getUniqueId(), 1, Integer::sum);
        if (hits >= 4) {
            aegis.put(p.getUniqueId(), 0);
            e.setCancelled(true);
            p.getWorld().playSound(p.getLocation(), Sound.ITEM_SHIELD_BLOCK, 1f, 1f);
            p.sendActionBar(Component.text("Щит: удар заблокирован!", NamedTextColor.GOLD));
        } else {
            p.sendActionBar(Component.text("Щит: удар " + hits + "/3 прошёл", NamedTextColor.GRAY));
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        aegis.remove(e.getPlayer().getUniqueId());
        busy.remove(e.getPlayer().getUniqueId());
    }

    // ------------------------------------------------------------------
    // Чары на мечах: Вампиризм, Гром, Обморожение
    // ------------------------------------------------------------------
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onAttack(EntityDamageByEntityEvent e) {
        if (!(e.getDamager() instanceof Player p)) return;
        if (!(e.getEntity() instanceof LivingEntity v)) return;
        ItemStack sword = p.getInventory().getItemInMainHand();
        if (sword.getType().isAir() || !sword.hasItemMeta()) return;

        if (Items.has(sword, CE.VAMPIRISM)) {
            double heal = e.getFinalDamage() * 0.3;
            double max = p.getAttribute(Attribute.MAX_HEALTH).getValue();
            p.setHealth(Math.min(max, p.getHealth() + heal));
        }
        if (Items.has(sword, CE.LIGHTNING) && ThreadLocalRandom.current().nextDouble() < 0.2) {
            v.getWorld().strikeLightningEffect(v.getLocation());
            v.setFireTicks(60);
            e.setDamage(e.getDamage() + 5);
        }
        if (Items.has(sword, CE.FROSTBITE)) {
            v.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 80, 1));
            v.setFreezeTicks(v.getMaxFreezeTicks());
        }
    }

    // ------------------------------------------------------------------
    // Лёгкое падение
    // ------------------------------------------------------------------
    @EventHandler(ignoreCancelled = true)
    public void onFall(EntityDamageEvent e) {
        if (e.getCause() == EntityDamageEvent.DamageCause.FALL
                && e.getEntity() instanceof Player p
                && Items.has(p.getInventory().getBoots(), CE.FEATHER)) {
            e.setCancelled(true);
        }
    }

    // ------------------------------------------------------------------
    // Спавн книг в сундуках по всей карте
    // ------------------------------------------------------------------
    @EventHandler
    public void onLoot(LootGenerateEvent e) {
        ThreadLocalRandom rnd = ThreadLocalRandom.current();
        for (CE c : CE.values()) {
            if (rnd.nextDouble() * 100.0 < c.chance) {
                e.getLoot().add(Items.book(c));
            }
        }
    }

    // ------------------------------------------------------------------
    // Наложение чара через наковальню: книга + предмет
    // ------------------------------------------------------------------
    @EventHandler
    public void onAnvil(PrepareAnvilEvent e) {
        AnvilInventory inv = e.getInventory();
        ItemStack a = inv.getFirstItem();
        ItemStack b = inv.getSecondItem();
        if (a == null || b == null) return;
        if (b.getType() != Material.ENCHANTED_BOOK || a.getType() == Material.ENCHANTED_BOOK) return;

        List<CE> list = Items.enchants(b);
        if (list.isEmpty()) return;

        ItemStack current = e.getResult();
        ItemStack res = (current != null && !current.getType().isAir()) ? current.clone() : a.clone();
        boolean changed = false;
        for (CE c : list) {
            if (c.target.matches(a.getType()) && !Items.has(res, c)) {
                Items.add(res, c);
                changed = true;
            }
        }
        if (!changed) return;
        e.setResult(res);
        e.getView().setRepairCost(Math.max(e.getView().getRepairCost(), 8));
    }

    // ------------------------------------------------------------------
    // Периодические эффекты (вызывается из Main раз в 2 секунды)
    // ------------------------------------------------------------------
    public void tick() {
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (Items.has(p.getInventory().getBoots(), CE.SWIFTNESS)) {
                p.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 60, 1, true, false, false));
            }
            if (Items.has(p.getInventory().getHelmet(), CE.NIGHTVISION)) {
                p.addPotionEffect(new PotionEffect(PotionEffectType.NIGHT_VISION, 260, 0, true, false, false));
            }
        }
    }
}
