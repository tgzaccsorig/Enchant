package ru.ce;

import org.bukkit.plugin.java.JavaPlugin;

public final class Main extends JavaPlugin {
    private static Main instance;
    private final Events events = new Events();

    public static Main get() {
        return instance;
    }

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();
        loadChances();

        Cmd cmd = new Cmd();
        getServer().getPluginManager().registerEvents(events, this);
        getServer().getPluginManager().registerEvents(cmd, this);
        getCommand("ce").setExecutor(cmd);
        getCommand("ce").setTabCompleter(cmd);

        // Скороход / Ночное зрение обновляются раз в 2 секунды
        getServer().getScheduler().runTaskTimer(this, events::tick, 40L, 40L);

        getLogger().info("CustomEnchants включён: " + CE.values().length + " чаров.");
    }

    public void reload() {
        reloadConfig();
        loadChances();
    }

    private void loadChances() {
        for (CE c : CE.values()) {
            c.chance = getConfig().getDouble("chances." + c.id, c.chance);
        }
    }
}
