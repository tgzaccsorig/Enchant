package ru.ce;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;

/** Все кастомные чары. */
public enum CE {
    // --- читерные, очень редкие ---
    DRILL("drill", "Бур 3×3", Target.DIGGER, 0.4, NamedTextColor.GOLD,
            "Ломает область 3×3 за один удар"),
    AEGIS("aegis", "Щит", Target.CHEST, 0.4, NamedTextColor.GOLD,
            "3 удара проходят, 4-й полностью блокируется"),

    // --- остальные 10 ---
    VAMPIRISM("vampirism", "Вампиризм", Target.SWORD, 3.0, NamedTextColor.RED,
            "Лечит тебя на 30% от нанесённого урона"),
    LUMBERJACK("lumberjack", "Дровосек", Target.AXE, 4.0, NamedTextColor.GREEN,
            "Срубает всё дерево целиком"),
    SMELTER("smelter", "Плавильщик", Target.TOOL, 4.0, NamedTextColor.YELLOW,
            "Добытое сразу переплавляется"),
    MAGNET("magnet", "Магнит", Target.TOOL, 5.0, NamedTextColor.AQUA,
            "Добыча сразу летит в инвентарь"),
    LIGHTNING("lightning", "Гром", Target.SWORD, 2.0, NamedTextColor.LIGHT_PURPLE,
            "20% шанс ударить молнией (+5 урона)"),
    FEATHER("feather", "Лёгкое падение", Target.BOOTS, 4.0, NamedTextColor.WHITE,
            "Полностью убирает урон от падения"),
    SWIFTNESS("swiftness", "Скороход", Target.BOOTS, 3.0, NamedTextColor.GREEN,
            "Постоянная скорость II"),
    NIGHTVISION("nightvision", "Ночное зрение", Target.HELMET, 4.0, NamedTextColor.DARK_AQUA,
            "Постоянное ночное зрение"),
    VEINMINER("veinminer", "Жилокоп", Target.PICKAXE, 1.5, NamedTextColor.DARK_PURPLE,
            "Присядь и сломай руду - добудется вся жила"),
    FROSTBITE("frostbite", "Обморожение", Target.SWORD, 3.0, NamedTextColor.BLUE,
            "Замораживает и замедляет цель при ударе");

    public final String id;
    public final String title;
    public final Target target;
    public final NamedTextColor color;
    public final String desc;
    /** Шанс (в %) появления книги в каждом сгенерированном сундуке. Берётся из config.yml. */
    public double chance;

    CE(String id, String title, Target target, double chance, NamedTextColor color, String desc) {
        this.id = id;
        this.title = title;
        this.target = target;
        this.chance = chance;
        this.color = color;
        this.desc = desc;
    }

    public Component line() {
        return Component.text(title, color).decoration(TextDecoration.ITALIC, false);
    }

    public static CE byId(String id) {
        for (CE c : values()) {
            if (c.id.equalsIgnoreCase(id)) return c;
        }
        return null;
    }
}
